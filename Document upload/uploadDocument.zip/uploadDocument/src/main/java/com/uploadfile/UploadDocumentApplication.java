package com.uploadfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadDocumentApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadDocumentApplication.class, args);
	}

}
