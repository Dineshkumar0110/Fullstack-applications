package com.uploadfile.controller;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.MediaType;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.uploadfile.Entity.UploadFile;
import com.uploadfile.service.UploadFileService;

@RestController
@RequestMapping("/api/files")
@CrossOrigin("*")
public class FileController {

    private final UploadFileService fileService;

    public FileController(UploadFileService fileService) {
        this.fileService = fileService;
    }

    @PostMapping("/upload")
    public ResponseEntity<?> upload(@RequestParam("file") MultipartFile file) {
        try {
            // Validate allowed file types
            String ct = file.getContentType();
            if (ct == null || !(
                    ct.equals("application/pdf") ||
                    ct.equals("application/msword") ||
                    ct.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document") ||
                    ct.equals("application/vnd.ms-excel") ||
                    ct.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") ||
                    ct.equals("text/plain")
            )) {
                return ResponseEntity.badRequest().body("Only PDF, Word, Excel, and Text files are allowed!");
            }

            UploadFile saved = fileService.store(file);
//            return ResponseEntity.ok("File uploaded successfully with id: " + saved.getId());
            return ResponseEntity.ok(saved);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body("Failed to upload file");
        }
    }

    @GetMapping("/download")
    public List<?> list() {
        return fileService.listFiles().stream().map(f -> new Object() {
            public final Long id = f.getId();
            public final String filename = f.getFileName();
            public final String contentType = f.getContentType();
            public final Long size = f.getSize();
            public final java.time.LocalDateTime uploadedAt = f.getUploadedAt();
        }).collect(Collectors.toList());
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> download(@PathVariable Long id) {
        UploadFile f = fileService.getFile(id);
        if (f == null) return ResponseEntity.notFound().build();

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(f.getContentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + f.getFileName() + "\"")
                .body(f.getData());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        fileService.deleteFile(id);
        return ResponseEntity.ok(" File deleted successfully");
    }
}

