package com.uploadfile.service;


import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.uploadfile.Entity.UploadFile;
import com.uploadfile.repo.UploadFileRepo;

@Service
public class UploadFileService {

    private final UploadFileRepo repo;

    public UploadFileService(UploadFileRepo repo) {
        this.repo = repo;
    }

    public UploadFile store(MultipartFile file) throws IOException {
        UploadFile uploadFile = new UploadFile();
        uploadFile.setFileName(file.getOriginalFilename());
        uploadFile.setContentType(file.getContentType());
        uploadFile.setSize(file.getSize());
        uploadFile.setData(file.getBytes());
        uploadFile.setUploadedAt(LocalDateTime.now());

        return repo.save(uploadFile);
    }


    public List<UploadFile> listFiles() {
        return repo.findAll();
    }

    public UploadFile getFile(Long id) {
        return repo.findById(id).orElse(null);
    }

    public void deleteFile(Long id) {
        repo.deleteById(id);
    }
}
