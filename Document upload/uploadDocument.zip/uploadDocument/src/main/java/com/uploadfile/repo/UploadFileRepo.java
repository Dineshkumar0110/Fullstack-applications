package com.uploadfile.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.uploadfile.Entity.UploadFile;


public interface UploadFileRepo extends JpaRepository<UploadFile, Long> {
}
