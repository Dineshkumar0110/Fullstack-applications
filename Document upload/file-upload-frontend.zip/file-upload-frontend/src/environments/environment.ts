export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080/api/files'


//    production: true,
//   apiBaseUrl: 'https://myapp.com/api'
};