import { Routes } from '@angular/router';
import { FileUploadComponent } from '../app/components/file-upload/file-upload.component';


export const routes: Routes = [
   
  { path: '', redirectTo: 'files', pathMatch: 'full' },
  { path: 'files', component: FileUploadComponent }

];
