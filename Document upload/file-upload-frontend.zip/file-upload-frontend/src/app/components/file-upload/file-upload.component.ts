import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-file-upload',
  imports: [CommonModule, HttpClientModule],
  templateUrl: './file-upload.component.html',
  styleUrl: './file-upload.component.css'
})
export class FileUploadComponent {
     selectedFile: File | null = null;
     message: string = '';

  private apiUrl = 'http://localhost:8080/api/files/upload'; // Backend URL

  constructor(private http: HttpClient) {}

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  onUpload() {
    if (!this.selectedFile) {
      this.message = 'Please select a file first!';
      return;
    }

    const formData = new FormData();
    formData.append('file', this.selectedFile);

    this.http.post(this.apiUrl, formData).subscribe({
      next: () => {
        this.message = 'File uploaded successfully!';
      },
      error: () => {
        this.message = 'File upload failed!';
      }
    });
  }
}
